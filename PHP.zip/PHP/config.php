<?php
// 替换成你的数据库信息
$db_host = "localhost";
$db_name = "（your_db_name）";
$db_user = "（your_db_user）";
$db_pass = "（your_db_pwd）";

// PHP 8.2 下mysql连接使用异常处理（避免致命错误）
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// 严格判断连接错误
if ($conn->connect_errno !== 0) {
    // 不直接die，抛出异常由上层捕获（避免返回HTML）
    throw new Exception("数据库连接失败：" . $conn->connect_error . " (错误码：" . $conn->connect_errno . ")");
}

// PHP 8.2 下设置字符集，避免中文乱码
if (!$conn->set_charset("utf8mb4")) {
    throw new Exception("设置字符集失败：" . $conn->error);
}
?>