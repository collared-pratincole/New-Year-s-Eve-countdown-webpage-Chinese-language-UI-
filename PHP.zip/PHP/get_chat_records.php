<?php
// 引入数据库配置
require_once "config.php";

$chatList = [];
// 查询最新的聊天记录（按发送时间倒序，取100条）
$result = $conn->query("SELECT send_user, chat_content, send_time FROM chat_records ORDER BY send_time DESC LIMIT 100");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        array_unshift($chatList, $row); // 反转顺序，按时间正序显示
    }
}

echo json_encode([
    "code" => 200,
    "list" => $chatList
]);

$conn->close();
?>