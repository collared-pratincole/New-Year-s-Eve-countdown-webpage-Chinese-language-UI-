<?php
// 引入数据库配置
require_once "config.php";

$send_user = $_POST['send_user'] ?? '';
$content = $_POST['content'] ?? '';
$send_time = $_POST['send_time'] ?? time();

if (empty($send_user) || empty($content)) {
    echo json_encode(["code" => 400, "msg" => "参数不全"]);
    exit;
}

// 插入聊天记录
$stmt = $conn->prepare("INSERT INTO chat_records (send_user, chat_content, send_time) VALUES (?, ?, ?)");
$stmt->bind_param("ssi", $send_user, $content, $send_time);

if ($stmt->execute()) {
    echo json_encode(["code" => 200, "msg" => "保存成功"]);
} else {
    echo json_encode(["code" => 500, "msg" => "保存失败"]);
}

$stmt->close();
$conn->close();
?>