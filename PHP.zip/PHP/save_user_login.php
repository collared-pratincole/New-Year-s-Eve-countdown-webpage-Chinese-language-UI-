<?php
session_start();
// 引入数据库配置
require_once "config.php";

$user_name = $_POST['user_name'] ?? '';
if (empty($user_name)) {
    echo json_encode(["code" => 400, "msg" => "昵称不能为空"]);
    exit;
}

$session_id = session_id();
$login_time = time();

// 检查用户是否已存在，存在则更新登录时间和在线状态，不存在则新增
$stmt = $conn->prepare("SELECT * FROM chat_users WHERE user_name = ?");
$stmt->bind_param("s", $user_name);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // 更新用户信息
    $stmt = $conn->prepare("UPDATE chat_users SET login_time = ?, is_online = 1, session_id = ? WHERE user_name = ?");
    $stmt->bind_param("iss", $login_time, $session_id, $user_name);
} else {
    // 新增用户
    $stmt = $conn->prepare("INSERT INTO chat_users (user_name, login_time, is_online, session_id) VALUES (?, ?, 1, ?)");
    $stmt->bind_param("sis", $user_name, $login_time, $session_id);
}

if ($stmt->execute()) {
    echo json_encode(["code" => 200, "msg" => "登录成功"]);
} else {
    echo json_encode(["code" => 500, "msg" => "登录失败"]);
}

$stmt->close();
$conn->close();
?>