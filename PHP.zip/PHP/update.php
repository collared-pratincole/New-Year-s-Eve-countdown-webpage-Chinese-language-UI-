<?php
// 关键1：PHP 8.2 下强制设置JSON响应头，禁用HTML错误输出
header("Content-Type: application/json; charset=utf-8");
ini_set('display_errors', 0); // 关闭页面错误输出（避免返回HTML）
ini_set('log_errors', 1); // 开启错误日志（宝塔/wwwlogs可查看）
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT); // 屏蔽废弃语法警告，兼容PHP 8.2

session_start();

// 关键2：PHP 8.2 下确保session_id有效，兼容会话初始化逻辑
if (empty(session_id()) || session_id() === '0') {
    session_regenerate_id(true); // 强制生成唯一会话ID
}

// 初始化JSON返回数据（避免PHP 8.2 下未定义变量报错）
$response = [
    "online_count" => 0,
    "msg" => "success",
    "code" => 200
];

try {
    // 关键3：PHP 8.2 下使用require_once时，需确保文件存在，否则抛出异常
    $config_file = __DIR__ . '/config.php'; // 绝对路径，避免路径错误
    if (!file_exists($config_file)) {
        throw new Exception("配置文件不存在：" . $config_file);
    }
    require_once $config_file;

    // 关键4：PHP 8.2 下验证mysqli连接是否有效
    if (!isset($conn) || !$conn instanceof mysqli || $conn->connect_errno !== 0) {
        throw new Exception("数据库连接无效：" . (isset($conn) ? $conn->connect_error : "未创建连接"));
    }

    $session_id = session_id();
    $last_active = time();
    $expire_time = time() - 300; // 5分钟离线时间

    // 清理过期会话（PHP 8.2 下预处理语句必须显式关闭）
    $delete_sql = "DELETE FROM online_users WHERE last_active < ?";
    $stmt_delete = $conn->prepare($delete_sql);
    if (!$stmt_delete) {
        throw new Exception("清理过期会话SQL预处理失败：" . $conn->error);
    }
    // PHP 8.2 下bind_param参数类型必须严格匹配
    $stmt_delete->bind_param("i", $expire_time);
    if (!$stmt_delete->execute()) {
        throw new Exception("清理过期会话执行失败：" . $stmt_delete->error);
    }
    $stmt_delete->close(); // 显式关闭预处理语句，释放资源

    // 插入/更新当前会话（ON DUPLICATE KEY UPDATE 兼容PHP 8.2）
    $insert_sql = "INSERT INTO online_users (session_id, last_active) VALUES (?, ?) ON DUPLICATE KEY UPDATE last_active = ?";
    $stmt_insert = $conn->prepare($insert_sql);
    if (!$stmt_insert) {
        throw new Exception("插入会话SQL预处理失败：" . $conn->error);
    }
    // 严格绑定参数类型：s(字符串)、i(整数)、i(整数)
    $stmt_insert->bind_param("sii", $session_id, $last_active, $last_active);
    if (!$stmt_insert->execute()) {
        throw new Exception("插入会话执行失败：" . $stmt_insert->error);
    }
    $stmt_insert->close(); // 显式关闭预处理语句

    // 统计在线人数（PHP 8.2 下查询结果需显式判断）
    $result = $conn->query("SELECT COUNT(*) AS count FROM online_users");
    if (!$result) {
        throw new Exception("查询在线人数失败：" . $conn->error);
    }
    $row = $result->fetch_assoc();
    $result->free(); // 释放查询结果集，兼容PHP 8.2
    $online_count = isset($row['count']) ? (int)$row['count'] : 0;
    $response["online_count"] = $online_count;

    $conn->close(); // 关闭数据库连接
} catch (Exception $e) {
    // PHP 8.2 下统一捕获异常，返回JSON格式错误信息（不返回HTML）
    $response["msg"] = $e->getMessage();
    $response["online_count"] = 0;
    $response["code"] = 500;
    // 记录错误日志，便于排查
    error_log("[PHP 8.2 在线人数统计错误] " . date('Y-m-d H:i:s') . "：" . $e->getMessage());
}

// 关键5：PHP 8.2 下确保json_encode正常输出，处理中文不转义
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit; // 强制终止脚本，避免后续输出多余内容
?>