-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2026-01-21 13:19:33
-- 服务器版本： 5.7.44-log
-- PHP 版本： 8.2.28
-- 数据库： `rstj`

--
-- 表的结构 `chat_records`
--
CREATE TABLE `chat_records` (
  `record_id` int(11) NOT NULL COMMENT '记录ID',
  `send_user` varchar(50) NOT NULL COMMENT '发送者昵称',
  `receive_user` varchar(50) DEFAULT 'all' COMMENT '接收者（默认all=全体成员）',
  `chat_content` text NOT NULL COMMENT '聊天内容',
  `send_time` int(11) NOT NULL COMMENT '发送时间戳'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天历史记录表';