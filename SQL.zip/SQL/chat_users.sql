-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2026-01-21 13:20:02
-- 服务器版本： 5.7.44-log
-- PHP 版本： 8.2.28
-- 数据库： `rstj`

--
-- 表的结构 `chat_users`
--

CREATE TABLE `chat_users` (
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `user_name` varchar(50) NOT NULL COMMENT '用户昵称（唯一，不可重复）',
  `login_time` int(11) NOT NULL COMMENT '登录时间戳',
  `is_online` tinyint(1) DEFAULT '1' COMMENT '是否在线（1=在线，0=离线）',
  `session_id` varchar(255) DEFAULT NULL COMMENT '用户会话ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天用户信息表';
