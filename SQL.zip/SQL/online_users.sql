-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2026-01-21 13:20:17
-- 服务器版本： 5.7.44-log
-- PHP 版本： 8.2.28
-- 数据库： `rstj`

--
-- 表的结构 `online_users`
--

CREATE TABLE `online_users` (
  `session_id` varchar(255) NOT NULL COMMENT '用户会话ID',
  `last_active` int(11) NOT NULL COMMENT '最后活跃时间戳'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;